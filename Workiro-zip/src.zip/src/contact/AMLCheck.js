import React from 'react';

function AMLCheck() {
  return (
    <div>AMLCheck</div>
  )
}

export default AMLCheck